from flask import Flask, render_template, request, jsonify
import json
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from deep_translator import GoogleTranslator
from fuzzywuzzy import process
import os

# Download necessary NLTK data
nltk.download("punkt")
nltk.download("stopwords")

app = Flask(__name__)
app.secret_key = "your_very_secure_secret_key_12345!@#$%"

# Load chatbot data
try:
    with open("college_data.json", "r", encoding="utf-8") as f:
        category_responses = json.load(f)
except (FileNotFoundError, json.JSONDecodeError):
    category_responses = {}

# Preload stopwords
STOP_WORDS = set(stopwords.words("english"))

def preprocess_text(text):
    """Remove stopwords, tokenize, and clean user query."""
    words = word_tokenize(text.lower())
    filtered_words = [word for word in words if word.isalnum() and word not in STOP_WORDS]
    return " ".join(filtered_words)

def translate_text(text, source_lang, target_lang):
    """Translate text using GoogleTranslator with exception handling."""
    try:
        return GoogleTranslator(source=source_lang, target=target_lang).translate(text)
    except Exception as e:
        print(f"Translation failed: {e}")
        return text  # Return original text if translation fails

@app.route("/")
def home():
    return render_template("index1.html", chat_history=[])

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_query = data.get("query", "").strip()
    user_lang = data.get("language", "en")

    if not user_query:
        return jsonify({"response": "Please enter a valid query."})

    # Translate user query to English
    processed_query = translate_text(user_query, user_lang, "en")
    processed_query = preprocess_text(processed_query)

    # Find best match response with fuzzy matching
    best_match_result = process.extractOne(processed_query, category_responses.keys(), score_cutoff=70)

    if best_match_result:
        best_match, score = best_match_result
        response = category_responses.get(best_match, "Sorry, I couldn't find relevant information.")
    else:
        response = "Sorry, I couldn't find the information. Please try rephrasing."

    # Translate response back to user's language
    response_translated = translate_text(response, "en", user_lang)

    return jsonify({"response": response_translated})

if __name__ == "__main__":
    app.run(debug=True)
